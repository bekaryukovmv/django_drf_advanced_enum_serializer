from django.apps import AppConfig


class AdvancedEnumDRFConfig(AppConfig):
    name = "advanced_enum_drf"
