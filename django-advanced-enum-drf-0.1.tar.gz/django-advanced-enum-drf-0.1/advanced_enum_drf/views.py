from django.db.models.enums import ChoicesMeta
from django.db.models.query import QuerySet
from rest_framework.generics import ListAPIView

from .serializers import ChoicedListSerializer

from .mixins import ListChoiceFilteredMixin


class ChoicesListView(ListChoiceFilteredMixin, ListAPIView):
    serializer_class = ChoicedListSerializer

    def filter_queryset(self, queryset):
        return self.search_order_query(self.search_filter_query(queryset))

    def get_queryset(self):
        assert self.queryset is not None, (
            "'%s' should either include a `queryset` attribute, "
            "or override the `get_queryset()` method." % self.__class__.__name__
        )

        queryset = self.queryset
        print(queryset)
        if isinstance(queryset, QuerySet):
            queryset = queryset.all()
        elif isinstance(queryset, ChoicesMeta):
            queryset = [{"value": key, "display_name": key.label} for key in queryset]
        elif isinstance(queryset[0], tuple):
            queryset = [{"value": key, "display_name": val} for (key, val) in queryset]

        return queryset
